//FS and Express Packages
const fs = require('fs');
const express = require('express');

//Setup Server Requirements
var app = require('express')();
var io = require('socket.io')(http);
var http = require('http').Server(app);
var bodyParser = require('body-parser');

var port = process.env.PORT || 3000;

//Body Parser
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

//Setup Encryption
var key = process.env.secret_key;
var encryptor = require('simple-encryptor')(key);

//Run Tests
const account_exists = 'Account Exists? ';
const password_correct = 'Password Matches? ';

//Local Variables
var logged_in = false;
var local_password = '';
var x = false;

//XSS Protection
function removeTags(str) {
  if ((str===null) || (str===''))
    return false;
  else
    str = str.toString();
    return str.replace( /(<([^>]+)>)/ig, '');
}

//Create account for SciFi Coms
app.post('/create_account', function(req, res){
  var username_to_be_created = req.body.username;
  var password_to_be_used = req.body.password;

  let user_path = __dirname+'/public/accounts/'+username_to_be_created+'/';
  
  //Passes Tests?
  if (fs.existsSync(user_path)){
  
    console.log(account_exists+'PASSED');

    res.sendFile(__dirname+'/public/ac_exists.html');
  }
  else{

    console.log(account_exists+'FAILED');
    
    //Create User Path
    fs.mkdir(user_path, function(err){
      if (err) {
        console.log(err);
      }
      else{
        console.log('Created User Path at: '+user_path);
      }
    });
    
    //Setup Password
    fs.appendFile(user_path+'pwd.txt', encryptor.encrypt(password_to_be_used), function(err){
      if(err){
        console.log(err);
      }
      else{
        console.log('Password created at: '+user_path+'pwd.txt');
      }
    });
     
    logged_in = true;

    res.sendFile(__dirname+'/public/logged_in.html');
  }
});

app.post('/login', function(req, res){
  var username_to_be_created = req.body.log_username;
  var password_to_be_used = req.body.log_password;

  let user_path = __dirname+'/public/accounts/'+username_to_be_created+'/';

  //Passes Tests?
  if (fs.existsSync(user_path)){

    console.log(account_exists+'PASSED');

    fs.readFile(user_path+'pwd.txt', 'utf8', function(err, data){
      if (err){
        console.log(err);
      }
      else{
        local_password = data;
      }
    });

    if (password_to_be_used == encryptor.decrypt(local_password)){
      x = true;
    }
    else{
      x = false;
    }

    if (x == true){
      logged_in = true;
      res.sendFile(__dirname+'/public/logged_in.html');
    }
    else{
      res.sendFile(__dirname+'/public/pwd_incorrect.html');
    }
  }
  else{

    console.log(account_exists+'FAILED');

    res.sendFile(__dirname+'/public/ac_false.html');
  }
});

app.get('/loggedin', function(req, res){
  if (logged_in == true){
    res.send(`
<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard</title>

    <!-- Local CSS Files -->
    <link href="https://SciFiComz.codesalvageon.repl.co/css/style.css" rel="stylesheet" type="text/css"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">

    <!-- Viewport -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
  </head>
  <body>
    <div class="text-box center">
      <h1>SciFi Comz Options</h1>
    </div>
    
    <div id="logged-in-buttons">
      <div class="text-box center">
        <button class="text-box-option zoom" onclick="createComClick()">Create Com</button><button class="text-box-option zoom" onclick="joinComClick()">Join Com</button>
      </div>

      <div class="text-box center">
        <button class="text-box-option zoom" onclick="viewPublicComsClick()">View Public Coms</button>
      </div>
    </div>

    <div class="text-box center" id="create-coms-form">
      <button class="input" onclick="createComBackClick()">Return</button>
      <form action="/create_com" method="POST" id="create-com-form-id">
        <h3>Com Name: <input type="text" class="input" name="com_name" id="com-name" required/></h3>
        <br/>
        <h3>Com Type: <select name="comtype" class="input" id="com-select">
          <option value="cf">Coalition Coms</option>
          <option value="df">Deposition Coms</option>
        </select></h3>
        <br/>
        <h3>Private or Public: <select name="public_opt" class="input" id="is-public">
          <option value="public">Public</option>
          <option value="private">Private</option>
        </select></h3>
        <br/>
        <input type="submit" class="input" value="Create Com"/>
      </form>
    </div>

    <div class="text-box center" id="join-coms-form">
      <button class="input" onclick="joinComBackClick()">Return</button>
      <form action="" method="POST">
        <h3>Com Name: <input type="text" class="input" id="envy"/></h3>
        <input type="submit" class="input" value="Join Com" />
      </form>
    </div>

    <div id="public-coms-iframe" class="center">
      <button class="input center" onclick="viewPublicComsBackClick()">Return</button>
      <iframe src="https://SciFiComz.codesalvageon.repl.co/public-coms.html" class="iframe" frameBorder="0" width="700" height="600"></iframe>
    </div>

    <div id="manage-coms-iframe" class="center">
      <button class="input" onclick="manageComsBackClick()">Return</button>
      <iframe src="" class="iframe center" frameBorder="0" width="700" height="600"></iframe>
    </div>

    <div id="chat-frame" class="center">
    </div>
  
    <!-- JQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Handle Button Clicks -->
    <script src="https://SciFiComz.codesalvageon.repl.co/scripts/button_click.js"></script>

    <!-- Handle Show and Hide functions -->
    <script src="https://SciFiComz.codesalvageon.repl.co/scripts/hide-show.js"></script>

    <!-- Handle localStorage functions -->
    <script src="https://SciFiComz.codesalvageon.repl.co/scripts/storage.js"></script>

    <!-- Send data to server -->
    <script src="https://SciFiComz.codesalvageon.repl.co/scripts/send-data.js"></script>
  </body>
</html>
    `);
    logged_in = false;
  }
  else{
    res.send('<script>location = "https://SciFiComz.codesalvageon.repl.co";</script>');
  }
});

app.post('/create_com', function(req, res){
  var comname = req.body.com_name;
  var comtype = req.body.comtype;
  var is_public = req.body.public_opt;

  let com_path = __dirname+'/public/coms/'+comname+'.html';
  let com_storage_path = __dirname+'/public/coms/'+comname+'s.html';

  if (fs.existsSync(com_storage_path)){
    res.send('com exists');
  }
  else{
    if (comtype == 'cf'){
      fs.appendFile(com_storage_path, `
<head>
  <title>`+comname+`</title>

  <link href="https://SciFiComz.codesalvageon.repl.co/css/cf.css" rel="stylesheet" type="text/css"/>

  <link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/xmlhttp.js"></script>
  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/storage.js"></script>

  <script> 
        link = 'https://SciFiComz.codesalvageon.repl.co/coms/`+comname+`s.html';
        $(document).ready(function() { 
          $(document).scrollTop($(document).height()); 
        }); 
  </script>
</head>
<div id="chatroom">
<ul>
      `, function(err){
        if (err){
          console.log(err);
        }
        else{
          console.log('Created Com Storage at path: '+com_storage_path);
        }
      });
    }
    else{
      fs.appendFile(com_storage_path, `
<head>
  <title>`+comname+`</title>

  <link href="https://SciFiComz.codesalvageon.repl.co/css/df.css" rel="stylesheet" type="text/css"/>

  <link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/xmlhttp.js"></script>
  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/storage.js"></script>

  <script> 
        link = 'https://SciFiComz.codesalvageon.repl.co/coms/`+comname+`s.html';
        $(document).ready(function() { 
          $(document).scrollTop($(document).height()); 
        }); 
  </script> 
</head>
<div id="chatroom">
<ul>
      `, function(err){
        if (err){
          console.log(err);
        }
        else{
          console.log('Created Com Storage at path: '+com_storage_path);
        }
      });
    }
    
    fs.appendFile(com_path, `
<head>
  <title>`+comname+`</title>

  <link href="https://SciFiComz.codesalvageon.repl.co/css/style.css" rel="stylesheet" type="text/css"/>

  <link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/storage.js"></script>
  <script src="https://SciFiComz.codesalvageon.repl.co/scripts/send-data.js"></script>
</head>
<button class="input center" onclick="location = 'https://SciFiComz.codesalvageon.repl.co/public-coms.html';">Return</button>
<iframe class="iframe center" width="600" height="500" frameBorder="0" src="https://SciFiComz.codesalvageon.repl.co/coms/`+comname+`s.html"></iframe>
<form class="center" onsubmit="getUsername()" id="message-form" method="POST" action="/chat">
  <input type="text" class="input" value="`+comname+`" name="com_place" readonly/><input type="text" class="input" name="com_username" id="username" readonly/>
  <hr/>
  <input type="text" class="input" name="message" id="message-send"/><input type="submit" class="input" value="Send Message"/>
</form>
    `, function(err){
      if (err){
        console.log(err);
      }
      else{
        console.log('Created Com Interface at: '+com_path);

        if (is_public == 'public'){
          unclean_sin = comname.toString();
          jesus = unclean_sin.replace( /(<([^>]+)>)/ig, '');

          fs.appendFile(__dirname+'/public/public-coms.html', `
          <a href="https://SciFiComz.codesalvageon.repl.co/coms/`+comname+`.html"><h3>`+jesus+`</h3></a>
        `, function(err){
          if (err){
            console.log(err);
          }
          else{
            console.log('logged public');
          }
        });
        }
        else{
          console.log('logged private');
        }

        res.send('com success');
      }
    });
  }
});

app.post('/chat', function(req, res){
  var chat_room = req.body.com_place;
  var user_name = req.body.com_username;
  var user_message = req.body.message;

  let chat_path = __dirname+'/public/coms/'+chat_room+'s.html';

  str = user_message.toString();
  smh = str.replace( /(<([^>]+)>)/ig, '');

  kk = user_name.toString();
  ok = kk.replace( /(<([^>]+)>)/ig, '');

  fs.appendFile(chat_path, `
<div class="message"><h3>
`+ok+`: `+smh+`
</h3></div>
  `, function(err){
    if (err){
      console.log(err);
    }
    else{
      console.log('Sent Message!');
    }
  });

});

app.use(function(req, res) {
  res.sendFile(__dirname+'/public/404.html', 404);
});

http.listen(port, function(){
  console.log('listening on *:' + port);
});