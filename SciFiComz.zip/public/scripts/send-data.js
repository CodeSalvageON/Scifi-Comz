//Script for sending data to server without reloading the page

//Chat without reloading page
function submitForm() {
    var http = new XMLHttpRequest();

    //Send stuff to the server
    http.open("POST", "https://SciFiComz.codesalvageon.repl.co/chat", true);
    http.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    var params = "message=" + document.getElementById('message-send').value; 
    http.send(params);
}

$('#message-form').submit(function(event){
  event.preventDefault()
  submitForm();

  document.getElementById('message-send').value = '';
});

//Create Com
function createCom() {
  var http = new XMLHttpRequest();

  //Send data to server
  http.open("POST", "https://SciFiComz.codesalvageon.repl.co/create_com", true);
  http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  var params = "com_name="+document.getElementById('com-name').value+"&comtype="+document.getElementById('com-select').value+"&public_opt="+document.getElementById('is-public').value;
  http.send(params);
}

$('#create-com-form-id').submit(function(event){
  event.preventDefault();
  createCom();

  hideLoggedSignupForm();
  document.getElementById('chat-frame').innerHTML = '<button class="input center" onclick="returnIframeBackClick()">Return</button><iframe src="https://SciFiComz.codesalvageon.repl.co/coms/'+document.getElementById('com-name').value+'.html" class="iframe" width="700" height="700"></iframe>';
});

//Join Com
$('#join-coms-form').submit(function(event){
  event.preventDefault();

  hideLoggedLoginForm();
  document.getElementById('chat-frame').innerHTML = '<button class="input center" onclick="returnIframeBackClick()">Return</button><iframe src="https://SciFiComz.codesalvageon.repl.co/coms/'+document.getElementById('envy').value+'.html" class="iframe" width="700" height="700"></iframe>';
});