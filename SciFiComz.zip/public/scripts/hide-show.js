//Script for hiding and showing objects
$('#ca-form').hide();
$('#login-form').hide();
$('#create-coms-form').hide();
$('#join-coms-form').hide();
$('#public-coms-iframe').hide();
$('#manage-coms-iframe').hide();

//Show and Hide buttons on index.html
function showIndexButtons(){
  $('#buttons-on-index').show();
}

function hideIndexButtons(){
  $('#buttons-on-index').hide();
}

//Show and Hide signup and login forms
function showCaForm(){
  $('#ca-form').show();
}

function hideCaForm(){
  $('#ca-form').hide();
}

function showLoginForm(){
  $('#login-form').show();
}

function hideLoginForm(){
  $('#login-form').hide();
}

//Show and Hide groups of buttons on /loggedin
function showLoggedInButtons(){
  $('#logged-in-buttons').show();
}

function hideLoggedInButtons(){
  $('#logged-in-buttons').hide();
}

//Show and Hide login and signup forms on /loggedin
function showLoggedLoginForm(){
  $('#join-coms-form').show();
}

function hideLoggedLoginForm(){
  $('#join-coms-form').hide();
}

function showLoggedSignupForm(){
  $('#create-coms-form').show();
}

function hideLoggedSignupForm(){
  $('#create-coms-form').hide();
}

//Show and Hide iframes on /loggedin 
function showPublicComsIframe(){
  $('#public-coms-iframe').show();
}

function hidePublicComsIframe(){
  $('#public-coms-iframe').hide();
}

function showManageComsIframe(){
  $('#manage-coms-iframe').show();
}

function hideManageComsIframe(){
  $('#manage-coms-iframe').hide();
}