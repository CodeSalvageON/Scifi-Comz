function returnHomeClick() {
  location = 'https://SciFiComz.codesalvageon.repl.co';
}

function create_accountClick(){
  hideIndexButtons();
  showCaForm();
}

function create_accountBackClick(){
  showIndexButtons();
  hideCaForm();
}

function log_inClick(){
  hideIndexButtons();
  showLoginForm();
}

function log_inBackClick(){
  showIndexButtons();
  hideLoginForm();
}

function createComClick(){
  hideLoggedInButtons();
  showLoggedSignupForm();
}

function createComBackClick(){
  showLoggedInButtons();
  hideLoggedSignupForm();
}

function joinComClick(){
  hideLoggedInButtons();
  showLoggedLoginForm();
}

function joinComBackClick(){
  showLoggedInButtons();
  hideLoggedLoginForm();
}

function viewPublicComsClick(){
  hideLoggedInButtons();
  showPublicComsIframe();
}

function viewPublicComsBackClick(){
  showLoggedInButtons();
  hidePublicComsIframe();
}

function manageComsClick(){
  hideLoggedInButtons();
  showManageComsIframe();
}

function manageComsBackClick(){
  showLoggedInButtons();
  hideManageComsIframe();
}

function returnIframeBackClick(){
  document.getElementById('chat-frame').innerHTML = '';
  showLoggedSignupForm();
}