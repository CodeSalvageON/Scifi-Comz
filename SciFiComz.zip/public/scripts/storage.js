//Script for storing localStorage Items on the client browser

//Set localStorage items from user input
function setUsername() {
  localStorage.setItem('username', document.getElementById('su-name').value);
}

function setUsernameFromLogin() {
  localStorage.setItem('username', document.getElementById('li-name').value);
}

//Get the localStorage items
function getUsername() {
  document.getElementById('username').value = localStorage.getItem('username');
}