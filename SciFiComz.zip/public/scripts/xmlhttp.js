//Script for getting some realtime chat!

var link = '';

var xhttp = new XMLHttpRequest();
  function loadXMLDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("chatroom").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", link, true);
  xhttp.send();
}
setInterval(loadXMLDoc, 50);